from .. import Provider as BarCodeProvider


class Provider(BarCodeProvider):
    pass
