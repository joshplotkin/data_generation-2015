from .. import Provider as FileProvider


class Provider(FileProvider):
    pass
