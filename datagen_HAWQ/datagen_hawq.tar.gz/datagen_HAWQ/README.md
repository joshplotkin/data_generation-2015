* required directories:
 * profiles (with main_config.json and other profile json files)
 * demographic_data with age_gender_demographics.csv and locations_partitions.csv
 * pickles directory
* run 'python make_pickles.py'
