from ..en import Provider as PersonProvider


class Provider(PersonProvider):
    pass
