DROP TYPE IF EXISTS transaction CASCADE;
CREATE TYPE transaction AS (
ssn text,
first text,
last text,
gender text,
street text,
city text,
state text,
zip text,
lat float8,
long float8,
city_pop integer,
job text,
dob text,
acct_num bigint,
profile text,
transnum integer,
transdate text,
category text,
amt text);

-- DROP TABLE IF EXISTS transactions_all CASCADE;
CREATE TABLE transactions_all (
ssn text,
first text,
last text,
gender text,
street text,
city text,
state text,
zip text,
lat float8,
long float8,
cizty_pop integer,
job text,
dob text,
acct_num bigint,
profile text,
transnum integer,
transdate text,
category text,
amt text)
DISTRIBUTED RANDOMLY;

DROP FUNCTION IF EXISTS customer(integer, text) CASCADE;
CREATE OR REPLACE FUNCTION customer(seed integer, repeat text)
    RETURNS SETOF transaction
AS
$$  
	import cPickle as pickle
	import faker
	from faker import Faker
	import numpy as np
	import sys
	import os

	sys.path.append('/home/gpadmin/Desktop/datagen_HAWQ')
	os.chdir('/home/gpadmin/Desktop/datagen_HAWQ/pickles')

	if repeat.lower() == 'true':
		np.random.seed(seed)

	fake = Faker()
	fake.seed(int(np.random.uniform(-1000000,1000000)))

	customer = pickle.load(open('generate_customer.pickle', 'rb'))
	alltrans = customer().generate_transactions()

	# see what's faster
	#for a in alltrans:
	#	yield(a)
	return [a for a in alltrans]
$$ 
LANGUAGE PLPYTHONU;


-- CREATE TEMPORARY TABLE select_node(node integer) DISTRIBUTED RANDOMLY;
-- INSERT INTO select_node
-- SELECT floor(random()*(10-1)+1) as node
-- FROM (SELECT generate_series(1,2)) q;

-- [pivhdsne:datagen_HAWQ]$ time psql -f hawq.sql -v customers=2
CREATE TEMPORARY TABLE numbers(n integer) DISTRIBUTED RANDOMLY;
INSERT INTO numbers
SELECT generate_series(1, :customers);

-- TODO: look into seed
INSERT INTO transactions_all
SELECT (t).* 
FROM 
	(SELECT (customer(1, 'True')) as t
	FROM (
		SELECT n 
		FROM numbers 
		)q
	)q2;
